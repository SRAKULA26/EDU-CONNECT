
First you should install python3.5/3.6 and Django
By default,you know how to  install python and you are already installed
To install Django

	pip install Django

OK , then open the directory
	cd AssignmentSubmission\assignment-submission-system
	python manage.py runserver

Then open the browser and input:
	127.0.0.1:8000

login student with
	name: student@2
	password: visg123456
login teacher with
	name: teacher@2
	password: visg123456
login Administrators with
	name: visg
	password: visg123456

Good luck,Happy coding!